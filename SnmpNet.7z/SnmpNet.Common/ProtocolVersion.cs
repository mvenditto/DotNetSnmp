﻿namespace SnmpNet.Common.Definitions
{
    public enum ProtocolVersion
    {
        SnmpV1 = 0,
        SnmpV2c = 1,
        SnmpV3 = 3
    }
}
