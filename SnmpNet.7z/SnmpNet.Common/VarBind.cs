﻿using SnmpNet.Asn1.Serialization;
using System.Formats.Asn1;

namespace SnmpNet.Asn1.SyntaxObjects
{
    public readonly record struct VarBind: IAsnSerializable
    {
        public readonly ObjectIdentifier Name { get;  }

        public readonly IAsnSerializable? Value { get; }

        public VarBind(string oid, IAsnSerializable? value = null)
        {
            Name = new ObjectIdentifier(oid);
            Value = value;
        }

        public void WriteTo(AsnWriter writer)
        {
            using (var varBind = writer.PushSequence())
            {
                writer.WriteObjectIdentifier(Name.Oid);

                if (Value == null)
                {
                    writer.WriteNull();
                }
                else
                {
                    Value.WriteTo(writer);
                }
            }
        }
    }
}
