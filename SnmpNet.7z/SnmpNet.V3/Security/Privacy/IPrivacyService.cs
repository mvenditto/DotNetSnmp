﻿namespace SnmpNet.Protocol.V3.Security.Privacy
{
    public interface IPrivacyService
    {
        public int PrivacyParametersLength { get; }
    }

}
