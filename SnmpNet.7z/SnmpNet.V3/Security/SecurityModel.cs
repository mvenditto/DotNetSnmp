﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnmpNet.Protocol.V3.Security
{
    public enum SecurityModel: byte
    {
        UserSecurityModel = 3
    }
}
