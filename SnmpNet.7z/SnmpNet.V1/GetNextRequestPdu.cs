﻿using SnmpNet.Asn1.Serialization;
using System.Formats.Asn1;

namespace SnmpNet.Protocol.V1
{
    public class GetNextRequestPdu: GetRequestPdu
    {
        public override Asn1Tag PduType => SnmpAsnTags.GetNextMsg;
    }
}
