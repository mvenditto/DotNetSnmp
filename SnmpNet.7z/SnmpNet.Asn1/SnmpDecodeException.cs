﻿using System.Runtime.Serialization;

namespace SnmpNet.Asn1.Serialization
{
    public class SnmpDecodeException : Exception
    {
        public SnmpDecodeException()
        {
        }

        public SnmpDecodeException(string? message) : base(message)
        {
        }

        public SnmpDecodeException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected SnmpDecodeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
