﻿using SnmpNet.Asn1.Serialization;
using System.Formats.Asn1;

namespace SnmpNet.Asn1.SyntaxObjects
{
    public readonly record struct Opaque(byte[] OctetString) : IAsnSerializable
    {
        public void WriteTo(AsnWriter writer)
        {
            writer.WriteOctetString(OctetString);
        }

        public static implicit operator byte[](Opaque o) => o.OctetString;
    }
}
